<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com  -->
<!--  Last Published: Thu Jul 18 2019 12:58:40 GMT+0000 (UTC)  -->
<html data-wf-page="5d24a0a2a07f784b9e33d1cc" data-wf-site="5d12117a5cf1540428d8d090">
<head>
  <meta charset="utf-8">
  <title>Join Us</title>
  <meta content="Join Us" property="og:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
 <link href="{{asset('css/normalize.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('css/webflow.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('css/tripleoklaw.webflow.css')}}" rel="stylesheet" type="text/css">
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="images/favicon.png" rel="shortcut icon" type="image/x-icon">
  <link href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png" rel="apple-touch-icon">
</head>
<body>
  <div data-collapse="medium" data-animation="default" data-duration="400" class="navbar w-nav">
     <div class="w-row">
      <div class="column-26 w-col w-col-5 w-col-tiny-6"><a href="/tripleok" class="brand w-nav-brand w--current"><img src="images/TripleOKlaw-Logo.png" alt=""></a></div>
      <div class="column-25 w-col w-col-7 w-col-tiny-6">
        <nav role="navigation" class="nav-menu w-nav-menu"><a href="/tripleok/about" class="nav-link w-nav-link">about us</a><a href="/tripleok/team" class="w-nav-link">TEAM</a><a href="/tripleok/practice" class="w-nav-link">PRACTICEs</a><a href="/tripleok/perspective" class="w-nav-link">PERSPECTIVE</a><a href="/tripleok/join" class="w-nav-link">JOIN US</a><a href="/tripleok/contact" class="w-nav-link">CONTACT US</a></nav>
        <div class="w-nav-button">
          <div class="icon-8 w-icon-nav-menu"></div>
        </div>
      </div>
    </div>
  </div>
  <div class="header-image">
    <div class="joinusbg">
      <div class="text-block-16">JOIN US</div>
    </div>
  </div>
  <div class="section-2-copy">
    <div class="w-container">
      <div class="text-block-2">Want to join us?</div>
      <div class="text-block-3">TRIPLEOKLAW is a great place to work. When hiring we look for above average professionals, with excellent academic credentials, great people skills, integrity and unmatched drive.If you think you have what it takes then please check below and click on one of the Current Opportunities at our firm. If no suitable openings are indicated you may still send us your Resume, via the Form below, to keep on file in case a suitable position does become available. You might also like to watch the video “What We Look for in Our People.”</div>
    </div>
  </div>
  <div class="section-13">
    <div class="w-container">
      <div>
        <div style="padding-top:56.17021276595745%" id="w-node-dd5ad24247ab-9e33d1cc" class="w-embed-youtubevideo"><iframe src="https://www.youtube.com/embed/pSByLy_F_G4?rel=0&amp;controls=1&amp;autoplay=0&amp;mute=0&amp;start=0" frameborder="0" style="position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:auto" allow="autoplay; encrypted-media" allowfullscreen=""></iframe></div>
      </div>
    </div>
  </div>
  @if($jobs)
  <div class="section-7">
    <div class="container-3 w-container">
      <div class="text-block-23">JOB OFFERS</div>
      @foreach($jobs as $job)
      <div class="div-block-11">
        <div class="w-row">
          <div class="w-col w-col-9">
            <div>
              <div class="text-block-24">{{$job->job_title}}</div>
              <div class="text-block-25">{!!html_entity_decode($job->job_body)!!} </div>
            </div>
          </div>
          <div class="column-13 w-col w-col-3"><a data-w-id="9fe3db0f-250f-b575-9493-e4d258073e57" href="/tripleok/application/{{$job->job_id}}" class="button-2 w-button">APPLY</a></div>
        </div>
      </div>
      @endforeach
    </div>
  </div>
  @endif
 <div class="footer">
    <div class="columns-9 w-row">
      <div class="w-col w-col-3"><a href="/tripleok" class="w-inline-block"><img src="{{asset('images/TripleOKlaw-Logo-copy3.png')}}" alt=""></a></div>
      <div class="w-col w-col-2">
        <div>
          <div class="div-block-13"><a href="/tripleok/about" class="link-3">ABOUT US</a></div>
          <div class="div-block-13"><a href="/tripleok/team" class="link-3">TEAM</a></div>
          <div class="div-block-13"><a href="/tripleok/practice" class="link-3">PRACTICES</a></div>
          <div class="div-block-13"><a href="/tripleok/perspective" class="link-3">PERSPECTIVE</a></div>
        </div>
      </div>
      <div class="w-col w-col-2">
        <div>
          <div class="div-block-13"><a href="/tripleok/join" class="link-3">JOIN US</a></div>
          <div class="div-block-13"><a href="/tripleok/contact" class="link-3">CONTACT US</a></div>
          <div class="div-block-13"><a href="/tripleok/rankings" class="link-3">RANKINGS</a></div>
          <div class="div-block-13"></div>
        </div>
      </div>
      <div class="w-col w-col-2">
        <div class="text-block-40">5th Floor, Block C, ACK Garden House, 1st Ngong’ Avenue, off Bishops Road<br>Nairobi, Kenya</div>
      </div>
      <div class="w-col w-col-3">
        <div class="text-block-41">T - +254 (20) 272 7171, 272 7164</div>
        <div class="text-block-41">F - +254 (0) 709 830 100</div>
        <div class="text-block-41-copy">info@tripleoklaw.com</div>
        <div class="social-icons"><a href="https://www.linkedin.com/company/tripleoklaw-advocates/" target="_blank" class="link-block-6-copy13 w-inline-block"><img src="{{asset('images/linkedin3.png')}}" alt="" class="image-8"></a><a href="https://twitter.com/TripleOKlawLLP" target="_blank" class="link-block-14 w-inline-block"><img src="{{asset('images/twitter3.png')}}" alt="" class="image-9"></a><a href="mailto:info@tripleoklaw.com" class="link-block-15 w-inline-block"><img src="{{asset('images/mail3.png')}}" alt="" class="image-10"></a><a href="#" class="link-block-16 w-inline-block"><img src="{{asset('images/WA-Logo3.png')}}" alt="" class="image-11"></a></div>
      </div>
    </div>
  </div>
  <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.4.1.min.220afd743d.js" type="text/javascript" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script src="js/webflow.js" type="text/javascript"></script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>
</html>